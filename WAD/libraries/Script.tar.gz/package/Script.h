#pragma once

extern "C" {
    #include "lua.h"
    #include "lualib.h"
    #include "lauxlib.h"
}
#include <unordered_map>
#include <string>
#include <iostream>
#include <algorithm>
#include <vector>

#define LuaLambda [](lua_State* L)->int

class Script {
private:
    lua_State* L;

    void push_value(int v) { lua_pushinteger(L, v); }
    void push_value(double v) { lua_pushnumber(L, v); }
    void push_value(float v) { lua_pushnumber(L, v); }
    void push_value(bool v) { lua_pushboolean(L, v); }
    void push_value(const char* v) { lua_pushstring(L, v); }
    void push_value(const std::string& v) { lua_pushstring(L, v.c_str()); }
    void push_value(lua_CFunction f) { lua_pushcfunction(L, f); }

public:
    Script(bool safeMode = true);
    ~Script();

    void ShowGlobals();

    void Run(const char* str);
    void RunFile(const char* file);

    template <typename T>
    void Send(const char* name, T value) {
        push_value(value);
        lua_setglobal(L, name);
    }

    template <typename T>
    void SendToTable(const char* tableName, const char* key, T value) {
        lua_getglobal(L, tableName);
        if (!lua_istable(L, -1)) {
            lua_pop(L, 1);
            lua_newtable(L);
            lua_pushvalue(L, -1); // isim karmaşıklığına kanma öncekinin kopyası
            lua_setglobal(L, tableName);
        }
        push_value(value);
        lua_setfield(L, -2, key);
        lua_pop(L, 1);
    }

    template <typename... Args>
    void Call(const char* funcName, Args... args) {
        lua_getglobal(L, funcName);
        if (!lua_isfunction(L, -1)) {
            std::cerr << "[Lua Error] '" << funcName << "' is not a function or not found." << std::endl;
            lua_pop(L, 1);
            return;
        }
        (push_value(args), ...);
        if (lua_pcall(L, sizeof...(args), 0, 0) != LUA_OK) {
            std::cerr << "[Lua Error] " << lua_tostring(L, -1) << std::endl;
            lua_pop(L, 1);
        }
    }
};
